package mum.edu.week1ExtraCredit.service;

import mum.edu.week1ExtraCredit.domain.Volunteer;

public interface IVolunteerService {
	public void AddVolunteer(Volunteer volunteer);
}
