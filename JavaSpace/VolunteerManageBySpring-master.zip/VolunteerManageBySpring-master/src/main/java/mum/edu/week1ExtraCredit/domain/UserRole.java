/**
 * 
 */
package mum.edu.week1ExtraCredit.domain;

/**
 * @author Chao Ping
 *
 */
public enum UserRole {
	ADMINISTRATOR, VOLUNTEER;
}
