/**
 * 
 */
package mum.edu.week1ExtraCredit.domain;

/**
 * @author Chao Ping
 *
 */
public enum Status {
	INPROGRESS, DELAYED, COMPLETED, PAUSED;
}
