package mum.edu.week1ExtraCredit.dao;

import mum.edu.week1ExtraCredit.domain.Volunteer;

public interface IVolunteerDAO {
	public void AddVolunteer(Volunteer volunteer);
}
