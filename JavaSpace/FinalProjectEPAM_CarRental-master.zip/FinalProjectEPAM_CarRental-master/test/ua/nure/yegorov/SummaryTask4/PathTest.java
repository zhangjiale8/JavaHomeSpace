package ua.nure.yegorov.SummaryTask4;

import org.junit.Test;

public class PathTest {

	@Test
	public void test() {
		new Path();
	}

}
