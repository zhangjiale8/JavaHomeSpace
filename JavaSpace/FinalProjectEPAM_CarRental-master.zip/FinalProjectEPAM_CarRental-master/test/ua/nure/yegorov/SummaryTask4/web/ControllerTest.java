package ua.nure.yegorov.SummaryTask4.web;

import static org.junit.Assert.*;

import org.junit.Test;

public class ControllerTest {

	@Test
	public void test() {
		Controller con = new Controller();
	}

}
