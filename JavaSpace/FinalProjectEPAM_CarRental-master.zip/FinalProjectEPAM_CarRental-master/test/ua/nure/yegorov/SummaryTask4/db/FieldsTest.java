package ua.nure.yegorov.SummaryTask4.db;

import org.junit.Test;

public class FieldsTest {

	@Test
	public final void testConstructor() {
		new Fields();
	}

}
