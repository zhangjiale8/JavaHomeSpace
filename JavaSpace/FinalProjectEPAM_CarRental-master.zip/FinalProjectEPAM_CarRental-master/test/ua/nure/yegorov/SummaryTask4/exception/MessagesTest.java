package ua.nure.yegorov.SummaryTask4.exception;

import org.junit.Test;

public class MessagesTest {

	@Test
	public void testMessages() {
		new Messages();
	}

}
