package ua.nure.yegorov.SummaryTask4.db;

/**
 * Status entity.
 * 
 * @author A.Yegorov
 *
 */

public enum Status {
	
	OPENED, CONFIRMED, REJECTED, PAID, CLOSED

}
