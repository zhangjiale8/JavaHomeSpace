package com.github.oneone1995.mvolunteer.service;

import com.github.oneone1995.mvolunteer.domain.ActivityStatus;

/**
 * Created by wangl on 2017/2/22.
 */
public interface ActivityStatusService {
    ActivityStatus getActivityStatusById(Integer id);
}
