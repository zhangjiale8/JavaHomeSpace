package com.github.oneone1995.mvolunteer.web.exception;

/**
 * @author Xiaoyue Xiao
 */
public class ServerInternalErrorException extends RuntimeException {

    private static final long serialVersionUID = -1168987160778410810L;

}
