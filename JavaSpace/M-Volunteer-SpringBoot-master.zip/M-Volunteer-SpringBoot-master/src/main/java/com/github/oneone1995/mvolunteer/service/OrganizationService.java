package com.github.oneone1995.mvolunteer.service;

import com.github.oneone1995.mvolunteer.domain.OrganizationInfo;

/**
 * Created by wangl on 2017/2/24.
 */
public interface OrganizationService {
    OrganizationInfo getOrganizationInfoBy(Integer id);
}
