package com.volunteerSystem.service;

import com.volunteerSystem.po.Admin;

public interface AdminService {
	//��½
	public boolean login(Admin adm);
}
