package com.volunteerSystem.service;

public interface AcademyService {
	
}
