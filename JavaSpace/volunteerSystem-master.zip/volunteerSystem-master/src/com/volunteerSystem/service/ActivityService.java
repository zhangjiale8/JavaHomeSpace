package com.volunteerSystem.service;

import java.util.List;

import com.volunteerSystem.po.Activity;

public interface ActivityService {
	//�õ����еĻ
	public List<Activity> getAll();
	
	//
}
