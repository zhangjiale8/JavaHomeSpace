# The-Web-of-Used-car-Trading-SSM-version-
二手车交易网站，使用SpringMVC+Spring+Mybatis三大框架整合版本
