package com.gzucm.volunteer.dao;

import com.gzucm.volunteer.domain.Information;
/**
 * 资讯表
 */
public interface IInformationDao extends ICommonDao<Information> {
	public static final String SERVICE_NAME="com.gzucm.volunteer.dao.impl.InformationDaoImpl";

}
