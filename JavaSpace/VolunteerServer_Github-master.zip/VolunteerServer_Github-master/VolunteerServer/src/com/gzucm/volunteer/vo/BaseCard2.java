package com.gzucm.volunteer.vo;
  
public class BaseCard2   
{  
   private Enlist enlist;
  
   public BaseCard2(Enlist enlist)  
   {  
       this.setEnlist(enlist);   
   }

	public Enlist getEnlist() {
		return enlist;
	}

public void setEnlist(Enlist enlist) {
	this.enlist = enlist;
}  
}  
