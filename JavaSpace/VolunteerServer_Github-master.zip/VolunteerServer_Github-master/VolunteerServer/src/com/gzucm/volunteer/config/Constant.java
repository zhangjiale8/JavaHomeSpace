package com.gzucm.volunteer.config;

public interface Constant {
	String SERVICE = "http://121.41.33.152/VolunteerServer/";
	String RESPONSE = "response";
	String APK_URL = SERVICE+"Volunteer.apk";
	String UPLOAD_IMG = "/upload/img/";
	String UPLOAD_ACTIVITY_IMG = "/upload/activityImg/";
}
