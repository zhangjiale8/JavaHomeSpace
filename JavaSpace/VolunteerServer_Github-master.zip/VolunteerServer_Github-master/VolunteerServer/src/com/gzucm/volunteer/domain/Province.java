package com.gzucm.volunteer.domain;

public class Province {
	private String provinceID;// 省会ID
	private String provinceName;// 省会名

	public String getProvinceName() {
		return provinceName;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public String getProvinceID() {
		return provinceID;
	}

	public void setProvinceID(String provinceID) {
		this.provinceID = provinceID;
	}
}
