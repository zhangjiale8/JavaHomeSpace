package com.gzucm.volunteer.dao;

import com.gzucm.volunteer.domain.UserInfo;

/**
 * 测试
 * @author 万允山
 *
 */
public interface ITestDao extends ICommonDao<UserInfo>{
	public static final String SERVICE_NAME="com.gzucm.volunteer.dao.impl.TestDaoImpl";

}
