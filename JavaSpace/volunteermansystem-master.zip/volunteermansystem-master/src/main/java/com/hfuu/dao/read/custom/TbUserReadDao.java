package com.hfuu.dao.read.custom;

import com.hfuu.dao.read.mbg.MBGTbUserReadDao;

public interface TbUserReadDao extends MBGTbUserReadDao {
}