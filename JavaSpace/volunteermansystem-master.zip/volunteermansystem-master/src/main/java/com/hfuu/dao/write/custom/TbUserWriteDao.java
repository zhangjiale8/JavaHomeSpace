package com.hfuu.dao.write.custom;

import com.hfuu.dao.write.mbg.MBGTbUserWriteDao;

public interface TbUserWriteDao extends MBGTbUserWriteDao {
}