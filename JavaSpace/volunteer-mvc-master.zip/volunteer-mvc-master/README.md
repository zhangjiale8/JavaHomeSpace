# volunteer-mvc
Simple single page MVC CRUD application that outputs a Volunteer database.

This App uses:
1. Spring
2. Hibernate
3. Bootstrap 3
4. Wenzhixi's Bootstrap Table
5. Sweet Alert
6. Jquery Validation

No Jsps for the output, just an html that uses post requests to the Spring backend (psuedo api)

![index](https://cloud.githubusercontent.com/assets/23427992/20536605/9b1f6626-b124-11e6-8edb-bb5f1bcfcf06.jpg)
![edit](https://cloud.githubusercontent.com/assets/23427992/20536633/b5cbff2a-b124-11e6-8f96-f8ce49100c13.jpg)
