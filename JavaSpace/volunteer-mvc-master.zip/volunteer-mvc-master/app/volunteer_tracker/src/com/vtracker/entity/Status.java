package com.vtracker.entity;

public enum Status {
	deactivated, activated, onHold
}
