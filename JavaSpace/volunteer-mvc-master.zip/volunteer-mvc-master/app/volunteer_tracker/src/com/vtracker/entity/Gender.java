package com.vtracker.entity;

public enum Gender {
	Male, Female
}
