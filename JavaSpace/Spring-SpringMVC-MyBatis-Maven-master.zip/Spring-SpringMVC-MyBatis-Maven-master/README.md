# SSMDemo
这是一个基于Maven的Spring+Spring MVC+MyBatis+MySQL整合SSM框架的学习demo    
开发环境：IntelliJ IDEA the Java IDE     
JDK：1.7     
Spring版本：3.2.0.RELEASE      
# 2017-03-09
更新了所有依赖版本，添加activeMQ，整合cxf      
Spring版本：4.3.3.RELEASE
# 2017-03-12
添加注册功能，实现注册后通过消息队列发送邮件     
# 2017-04-09
添加事务管理测试代码

