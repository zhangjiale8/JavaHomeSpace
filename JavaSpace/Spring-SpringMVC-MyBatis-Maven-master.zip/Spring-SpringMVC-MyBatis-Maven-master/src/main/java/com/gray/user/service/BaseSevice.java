package com.gray.user.service;

/**
 * Created by gray on 2017/4/8.
 */
public interface BaseSevice {
    public void insert(String sql);
    public void update(String sql);
    public void delete(String sql);
}
