package com.bmw.sell.value;

public class ServiceValue {
	
	private int serid=0;
	private String serdate=null;
	private String serstate=null;
	private String clientname=null;
	private int clientid=0;
	public int getSerid() {
		return serid;
	}
	public void setSerid(int serid) {
		this.serid = serid;
	}
	public String getSerdate() {
		return serdate;
	}
	public void setSerdate(String serdate) {
		this.serdate = serdate;
	}
	public String getSerstate() {
		return serstate;
	}
	public void setSerstate(String serstate) {
		this.serstate = serstate;
	}
	public String getClientname() {
		return clientname;
	}
	public void setClientname(String clientname) {
		this.clientname = clientname;
	}
	public int getClientid() {
		return clientid;
	}
	public void setClientid(int clientid) {
		this.clientid = clientid;
	}
	

}
