package com.bmw.sell.value;

public class ClientValue {
	
	private int clientid=0;
	private String clientname=null;
	private String clientsex=null;
	private int clientage=0;
	private String clientphone=null;
	private String clientmail=null;
	private int engineid=0;
	private String carname=null;
	private String selldate=null;
	public String getSelldate() {
		return selldate;
	}
	public void setSelldate(String selldate) {
		this.selldate = selldate;
	}
	public int getClientid() {
		return clientid;
	}
	public void setClientid(int clientid) {
		this.clientid = clientid;
	}
	public String getClientname() {
		return clientname;
	}
	public void setClientname(String clientname) {
		this.clientname = clientname;
	}
	public String getClientsex() {
		return clientsex;
	}
	public void setClientsex(String clientsex) {
		this.clientsex = clientsex;
	}
	public int getClientage() {
		return clientage;
	}
	public void setClientage(int clientage) {
		this.clientage = clientage;
	}
	public String getClientphone() {
		return clientphone;
	}
	public void setClientphone(String clientphone) {
		this.clientphone = clientphone;
	}
	public String getClientmail() {
		return clientmail;
	}
	public void setClientmail(String clientmail) {
		this.clientmail = clientmail;
	}
	public int getEngineid() {
		return engineid;
	}
	public void setEngineid(int engineid) {
		this.engineid = engineid;
	}
	public String getCarname() {
		return carname;
	}
	public void setCarname(String carname) {
		this.carname = carname;
	}
	
	
	
}
