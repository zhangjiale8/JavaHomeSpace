carsell
=======

A JavaEE project used jre7 and Mysql.一个使用jre7和Mysql数据库的JavaEE项目。

#### Description 项目说明
A very simple JavaEE project,Using the MVC development pattern. This is a car sell system, just for practiced ~

简单的JavaEE项目，使用MVC开发模式。做了一个汽车销售系统，全当练习了~

#### Runtime Environment 运行环境
JDK7+Mysql+Tomcat7

#### Database Information 数据库信息 
Using the `carsell.sql` in the root directory,directly import into Mysql.

Username:admin,Password:admin

使用根目录下的`carsell.sql`直接导入Mysql即可，初始登录账户是admin,密码也是admin

#### Database Connection Pool Configurations 数据连接池配置
Using the `context.xml` in the root directory.

使用根目录中的 `context.xml`配置