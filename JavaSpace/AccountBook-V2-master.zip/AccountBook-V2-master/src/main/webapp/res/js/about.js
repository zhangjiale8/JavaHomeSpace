function setLeftColumn(){
	$("#income").addClass("left-column-button-inactive");
	$("#income").addClass("left-column-button-inactive-font");
	$("#expenditure").addClass("left-column-button-inactive");
	$("#expenditure").addClass("left-column-button-inactive-font");
	$("#history").addClass("left-column-button-inactive");
	$("#history").addClass("left-column-button-inactive-font");
	$("#itemsManagement").addClass("left-column-button-inactive");
	$("#itemsManagement").addClass("left-column-button-inactive-font");
	$("#payMethodsManagement").addClass("left-column-button-inactive");
	$("#payMethodsManagement").addClass("left-column-button-inactive-font");
	$("#about").addClass("left-column-button-active");
	$("#about").addClass("left-column-button-active-font");
}
