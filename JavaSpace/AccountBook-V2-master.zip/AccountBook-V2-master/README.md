# AccountBook-V2
简单的记账系统：使用Maven作为项目管理，SSM（Spring，SpringMVC，MyBatis）开发框架。

<b>登录页</b><br>
http://59.110.231.132:8080/AccountBook-V2/userController/showUserLogin.action<br>
<b>项目搭建方法</b><br>
http://blog.csdn.net/taoxiuxia/article/details/77902197
