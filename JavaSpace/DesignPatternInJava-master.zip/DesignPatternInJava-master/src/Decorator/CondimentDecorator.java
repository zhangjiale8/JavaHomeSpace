package Decorator;

/**
 * Created by huangjunxiong on 2017/9/23.
 */
public abstract class CondimentDecorator extends Beverage{
    public abstract String getDesc();
}
