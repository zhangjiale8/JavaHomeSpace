package Factory;

/**
 * Created by lenovo on 2017/6/4.
 */
public class GreekPizza extends Pizza {
    @Override
    public String toString() {
        return "This is GreekPizza";
    }
}
