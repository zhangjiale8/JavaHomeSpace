package Factory.Abstract;

/**
 * Created by lenovo on 2017/6/4.
 */
public interface PizzaFactory {
    public String getMaterial();
    public String getPractice();
}
