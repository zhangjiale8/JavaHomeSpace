package Factory;

/**
 * Created by lenovo on 2017/6/4.
 */
public class ChicagoStyleCheesePizza extends CheesePizza {
    @Override
    public String toString() {
        return super.toString()+" of Chicago";
    }
}
