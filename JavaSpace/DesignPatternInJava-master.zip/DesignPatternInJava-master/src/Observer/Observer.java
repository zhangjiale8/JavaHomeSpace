package Observer;

/**
 * Created by huangjunxiong on 2017/8/13.
 */
public interface Observer {
    public void update(String context);
}
