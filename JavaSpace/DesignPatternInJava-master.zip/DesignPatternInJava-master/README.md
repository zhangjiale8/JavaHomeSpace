# DesignPatternInJava
## 设计模式学习笔记（Java语言描述）
单例模式 [我的博客](http://blog.csdn.net/donggua3694857/article/details/66612049)    
工厂模式 [我的博客](http://blog.csdn.net/donggua3694857/article/details/72862179)    
观察者模式 [我的博客](http://blog.csdn.net/donggua3694857/article/details/77146264)    
装饰者模式 [我的博客](http://blog.csdn.net/donggua3694857/article/details/78074727)
