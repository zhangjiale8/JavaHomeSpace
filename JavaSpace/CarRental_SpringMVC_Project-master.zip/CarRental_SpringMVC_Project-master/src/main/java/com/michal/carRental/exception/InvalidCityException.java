package com.michal.carRental.exception;

public class InvalidCityException extends RuntimeException{


	private static final long serialVersionUID = -8259299901178518601L;

	public InvalidCityException(long id)
	{
		
	}
	
	
}
