package com.michal.carRental.domain;

public enum UserStatus {
	ACTIVE,
	INACTIVE;
}
