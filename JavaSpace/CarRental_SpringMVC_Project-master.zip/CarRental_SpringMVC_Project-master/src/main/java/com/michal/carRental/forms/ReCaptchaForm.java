package com.michal.carRental.forms;


public class ReCaptchaForm {


	private String recaptchaResponse;

	public String getRecaptchaResponse() {
		return recaptchaResponse;
	}

	public void setRecaptchaResponse(String recaptchaResponse) {
		this.recaptchaResponse = recaptchaResponse;
	}
	
	
}
