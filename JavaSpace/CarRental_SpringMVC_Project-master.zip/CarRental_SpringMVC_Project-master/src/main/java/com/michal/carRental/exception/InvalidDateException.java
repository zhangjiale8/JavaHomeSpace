package com.michal.carRental.exception;

public class InvalidDateException extends RuntimeException {

	private static final long serialVersionUID = -6020410124819483838L;

}
