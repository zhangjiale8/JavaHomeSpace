package com.michal.carRental.service;

public interface ReCaptchaService {

	boolean isResponseValid(String response);
	
}
