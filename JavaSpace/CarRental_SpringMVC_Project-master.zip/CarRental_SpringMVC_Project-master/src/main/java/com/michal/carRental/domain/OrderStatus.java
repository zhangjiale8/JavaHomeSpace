package com.michal.carRental.domain;

public enum OrderStatus {
	ACTIVE,
	INACTIVE;
}
