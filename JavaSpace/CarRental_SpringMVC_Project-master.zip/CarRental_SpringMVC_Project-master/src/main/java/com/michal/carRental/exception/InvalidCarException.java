package com.michal.carRental.exception;

public class InvalidCarException extends RuntimeException {

	private static final long serialVersionUID = 4206845551942194856L;

}
