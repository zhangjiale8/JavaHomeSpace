﻿package com.bjb.dao;

import org.springframework.stereotype.Repository;
import com.bjb.entity.VolUserType;

@Repository(value="volUserTypeDao")
public interface VolUserTypeDao extends BasicDao<VolUserType> {
}
