﻿package com.bjb.dao;

import org.springframework.stereotype.Repository;
import com.bjb.entity.VolScoreStar;

@Repository(value="volScoreStarDao")
public interface VolScoreStarDao extends BasicDao<VolScoreStar> {
}
