package com.bjb;

public class Constants {
    /**
     * returnCode 1:成功
     */
    public static final int RETURN_CODE_0 = 0;
    
    public static final int RETURN_CODE_1 = 1;
    

    
    
}
