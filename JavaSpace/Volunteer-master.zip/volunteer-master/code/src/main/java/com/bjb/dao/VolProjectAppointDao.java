﻿package com.bjb.dao;

import org.springframework.stereotype.Repository;
import com.bjb.entity.VolProjectAppoint;

@Repository(value="volProjectAppointDao")
public interface VolProjectAppointDao extends BasicDao<VolProjectAppoint> {
}
