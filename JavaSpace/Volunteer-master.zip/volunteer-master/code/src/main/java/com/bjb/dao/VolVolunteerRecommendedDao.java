﻿package com.bjb.dao;

import org.springframework.stereotype.Repository;
import com.bjb.entity.VolVolunteerRecommended;

@Repository(value="volVolunteerRecommendedDao")
public interface VolVolunteerRecommendedDao extends BasicDao<VolVolunteerRecommended> {
}
