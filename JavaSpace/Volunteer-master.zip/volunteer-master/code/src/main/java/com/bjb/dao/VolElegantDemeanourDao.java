﻿package com.bjb.dao;

import org.springframework.stereotype.Repository;
import com.bjb.entity.VolElegantDemeanour;

@Repository(value="volElegantDemeanourDao")
public interface VolElegantDemeanourDao extends BasicDao<VolElegantDemeanour> {
}
