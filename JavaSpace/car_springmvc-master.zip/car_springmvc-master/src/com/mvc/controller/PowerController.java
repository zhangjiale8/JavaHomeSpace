package com.mvc.controller;

import org.springframework.stereotype.Controller;

/**
 * Created by lw on 14-3-21.
 */
@Controller
public class PowerController {

}
