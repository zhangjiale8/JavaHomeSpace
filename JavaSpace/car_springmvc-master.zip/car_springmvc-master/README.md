car_springmvc
=============

车辆租赁系统 springmvc demo Project

花了一周末做的一个毕设。
用吧友的话说是非常粗糙，入门还行！
