import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedList;


public class test {

	public static void main(String args[]){
		
		ArrayList<String> s = new ArrayList<String>();
		
	
		

		
		
		
		
		
	}
	
}
