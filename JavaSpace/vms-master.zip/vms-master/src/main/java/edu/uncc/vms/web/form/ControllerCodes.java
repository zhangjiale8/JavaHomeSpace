package edu.uncc.vms.web.form;

public interface ControllerCodes {
	
	String loginSuccess = "100";
	String logoutSuccess = "101";
	
	String userName="sachinmn39@gmail.com";
	String pass = "sachin39";
	
	String donationSuccess="102";
	String donationError="103";
	
	String eventDeleteSuccess="104";
	String eventDeleteError="105";
	
	String eventJoinError="106";
	String eventJoinDuplicate="107";
	String eventJoinSuccess="108";
}
