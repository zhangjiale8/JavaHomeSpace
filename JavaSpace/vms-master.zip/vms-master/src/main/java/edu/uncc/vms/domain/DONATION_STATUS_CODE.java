package edu.uncc.vms.domain;

public enum DONATION_STATUS_CODE {

	DONATION_SUCCESS, DONATION_ERROR
}
