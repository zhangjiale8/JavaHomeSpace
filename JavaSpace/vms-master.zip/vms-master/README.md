This is a Volunteer Management System (VMS), built using Spring MVC, bootstrap and MySQL

use mvn jetty:run command to build and run the application using jetty server

Application home screen url is http://localhost:8080/vms/showPosts