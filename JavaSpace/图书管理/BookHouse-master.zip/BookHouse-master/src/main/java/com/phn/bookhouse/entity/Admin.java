/**
 * 
 */
package com.phn.bookhouse.entity;

/**
 * @file Admin.java
 * @author pan
 * @date 2014年11月12日
 * @email panhainan@yeah.net
 */
public class Admin {
	private int admi_id;
	private String admi_login_name;
	private String admi_login_password;

	public int getAdmi_id() {
		return admi_id;
	}

	public void setAdmi_id(int admi_id) {
		this.admi_id = admi_id;
	}

	public String getAdmi_login_name() {
		return admi_login_name;
	}

	public void setAdmi_login_name(String admi_login_name) {
		this.admi_login_name = admi_login_name;
	}

	public String getAdmi_login_password() {
		return admi_login_password;
	}

	public void setAdmi_login_password(String admi_login_password) {
		this.admi_login_password = admi_login_password;
	}

}
