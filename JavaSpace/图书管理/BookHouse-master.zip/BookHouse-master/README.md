# BookHouse
<font size="4">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BookHouse网上书城，个人独自用SpringMVC+MyBatis+Spring等框架技术花2个星期时间开发的一个网上书城。
<br/><br/>
项目用到的相关技术、工具等
----------


开发平台及工具：Windows 8 | MyEclipse10.7

涉及的编程语言：Java  |  JavaScript  |  HTML

涉及的框架技术：**SpringMVC  |  Spring  |  MyBatis**

其他技术：Maven | CSS  |  JQuery  |  Ajax  |  JSON  |  JSP  |  Servlet  |  JSTL

数据库：MySQL 5.6

服务器：Tomcat 7.x


<br/><br/><br/>
<font color="red">注意：</font>**打开根目录里面的sql文件，在数据库软件中建一个bookhouse数据库，然后运行sql文件。还有数据库默认用户名root和密码123456，如果需要修改请到src下面修改jdbc.properties文件**
<br/><br/><br/>
点击查看<a href="http://panhainan.com/2015/04/28/BookHouse%E7%BD%91%E4%B8%8A%E4%B9%A6%E5%9F%8E%E4%BB%8B%E7%BB%8D/" target="_blank" >BookHouse网上书城系统详细介绍</a>
</font>
