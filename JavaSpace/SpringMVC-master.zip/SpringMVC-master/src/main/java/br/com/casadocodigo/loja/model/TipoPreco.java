package br.com.casadocodigo.loja.model;

public enum TipoPreco {
	EBOOK, IMPRESSO, COMBO;
}
