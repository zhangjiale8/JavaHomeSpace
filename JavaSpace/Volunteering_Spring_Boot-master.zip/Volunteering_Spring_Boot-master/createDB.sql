# DROP USER IF EXISTS 'test'@'localhost';

CREATE DATABASE IF NOT EXISTS test0;

CREATE USER IF NOT EXISTS 'test'@'localhost';
SET PASSWORD FOR 'test'@'localhost' = 'test';

GRANT ALL PRIVILEGES ON *.* TO 'test' WITH GRANT OPTION;
GRANT ALL PRIVILEGES ON test0.* TO 'test' WITH GRANT OPTION;
FLUSH PRIVILEGES;

DELETE FROM mysql.user WHERE user not in ('root','mysql.sys','test') AND host='localhost';
FLUSH PRIVILEGES;
