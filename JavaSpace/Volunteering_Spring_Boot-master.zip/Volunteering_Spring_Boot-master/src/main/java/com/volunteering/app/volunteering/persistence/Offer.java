package com.volunteering.app.volunteering.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

@Entity
@Table(name = "offer")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Offer implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 255)
    @Column(name = "name", length = 255, nullable = false)
    private String name;

    @Size(max = 1000)
    @Column(name = "description", length = 1000)
    private String description;

    @Size(max = 255)
    @Column(name = "volunteer_type", length = 255)
    private String volunteerType;

    @Column(name = "initial_no_vacancies")
    private Integer initialNoVacancies;

    @Column(name = "actual_no_vacancies")
    private Integer actualNoVacancies;

    @NotNull
    @Column(name = "date_from", nullable = false)
    private ZonedDateTime dateFrom;

    @NotNull
    @Column(name = "date_to", nullable = false)
    private ZonedDateTime dateTo;

    @Column(name = "workhours_per_month")
    private Integer workhoursPerMonth;

    @NotNull
    @Size(max = 255)
    @Column(name = "daytime", length = 255, nullable = false)
    private String daytime;

    @Size(max = 255)
    @Column(name = "workhours", length = 255)
    private String workhours;

    @ManyToOne(optional = false)
    @NotNull
    private StatusType statusType;

    @ManyToOne(optional = false)
    @NotNull
    private Program program;

    @ManyToOne
    private Term term;

    @OneToMany(mappedBy = "offer")
    @JsonIgnore
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Application> applications = new HashSet<>();

    @OneToMany(mappedBy = "offer")
    @JsonIgnore
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Requirement> requirements = new HashSet<>();

    @OneToMany(mappedBy = "offer")
    @JsonIgnore
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<OfferDetails> offerDetails = new HashSet<>();

    @OneToMany(mappedBy = "offer")
    @JsonIgnore
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Document> documents = new HashSet<>();

    public Long getId() {
        return id;
    }

    public Offer setId(Long id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public Offer setName(String name) {
        this.name = name;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public Offer setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getVolunteerType() {
        return volunteerType;
    }

    public Offer setVolunteerType(String volunteerType) {
        this.volunteerType = volunteerType;
        return this;
    }

    public Integer getInitialNoVacancies() {
        return initialNoVacancies;
    }

    public Offer setInitialNoVacancies(Integer initialNoVacancies) {
        this.initialNoVacancies = initialNoVacancies;
        return this;
    }

    public Integer getActualNoVacancies() {
        return actualNoVacancies;
    }

    public Offer setActualNoVacancies(Integer actualNoVacancies) {
        this.actualNoVacancies = actualNoVacancies;
        return this;
    }

    public ZonedDateTime getDateFrom() {
        return dateFrom;
    }

    public Offer setDateFrom(ZonedDateTime dateFrom) {
        this.dateFrom = dateFrom;
        return this;
    }

    public ZonedDateTime getDateTo() {
        return dateTo;
    }

    public Offer setDateTo(ZonedDateTime dateTo) {
        this.dateTo = dateTo;
        return this;
    }

    public Integer getWorkhoursPerMonth() {
        return workhoursPerMonth;
    }

    public Offer setWorkhoursPerMonth(Integer workhoursPerMonth) {
        this.workhoursPerMonth = workhoursPerMonth;
        return this;
    }

    public String getDaytime() {
        return daytime;
    }

    public Offer setDaytime(String daytime) {
        this.daytime = daytime;
        return this;
    }

    public String getWorkhours() {
        return workhours;
    }

    public Offer setWorkhours(String workhours) {
        this.workhours = workhours;
        return this;
    }

    public StatusType getStatusType() {
        return statusType;
    }

    public Offer setStatusType(StatusType statusType) {
        this.statusType = statusType;
        return this;
    }

    public Program getProgram() {
        return program;
    }

    public Offer setProgram(Program program) {
        this.program = program;
        return this;
    }

    public Term getTerm() {
        return term;
    }

    public Offer setTerm(Term term) {
        this.term = term;
        return this;
    }

    public Set<Application> getApplications() {
        return applications;
    }

    public Offer setApplications(Set<Application> applications) {
        this.applications = applications;
        return this;
    }

    public Offer addApplication(Application application) {
        this.applications.add(application);
        application.setOffer(this);
        return this;
    }

    public Offer removeApplication(Application application) {
        this.applications.remove(application);
        application.setOffer(null);
        return this;
    }

    public Set<Requirement> getRequirements() {
        return requirements;
    }

    public Offer setRequirements(Set<Requirement> requirements) {
        this.requirements = requirements;
        return this;
    }

    public Offer addRequirement(Requirement requirement) {
        this.requirements.add(requirement);
        requirement.setOffer(this);
        return this;
    }

    public Offer removeRequirement(Requirement requirement) {
        this.requirements.remove(requirement);
        requirement.setOffer(null);
        return this;
    }


    public Set<OfferDetails> getOfferDetails() {
        return offerDetails;
    }

    public Offer setOfferDetails(Set<OfferDetails> offerDetails) {
        this.offerDetails = offerDetails;
        return this;
    }

    public Offer addOfferDetails(OfferDetails offerDetails) {
        this.offerDetails.add(offerDetails);
        offerDetails.setOffer(this);
        return this;
    }

    public Offer removeOfferDetails(OfferDetails offerDetails) {
        this.offerDetails.remove(offerDetails);
        offerDetails.setOffer(null);
        return this;
    }

    public Set<Document> getDocuments() {
        return documents;
    }

    public Offer setDocuments(Set<Document> documents) {
        this.documents = documents;
        return this;
    }

    public Offer addDocument(Document document) {
        this.documents.add(document);
        document.setOffer(this);
        return this;
    }

    public Offer removeDocument(Document document) {
        this.documents.remove(document);
        document.setOffer(null);
        return this;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Offer offer = (Offer) o;
        if (offer.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), offer.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Offer{" +
                "id=" + getId() +
                ", name='" + getName() + "'" +
                ", description='" + getDescription() + "'" +
                ", volunteerType='" + getVolunteerType() + "'" +
                ", initialNoVacancies='" + getInitialNoVacancies() + "'" +
                ", actualNoVacancies='" + getActualNoVacancies() + "'" +
                ", dateFrom='" + getDateFrom() + "'" +
                ", dateTo='" + getDateTo() + "'" +
                ", workhoursPerMonth='" + getWorkhoursPerMonth() + "'" +
                ", daytime='" + getDaytime() + "'" +
                ", workhours='" + getWorkhours() + "'" +
                "}";
    }
}
