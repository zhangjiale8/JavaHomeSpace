package com.volunteering.app.volunteering.persistence;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "offer_details")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class OfferDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @Size(max = 1000)
    @Column(name = "description", length = 1000)
    private String description;

    @NotNull
    @Size(max = 1)
    @Column(name = "is_valid", nullable = false)
    private boolean valid;

    @ManyToOne(optional = false)
    @NotNull
    private Offer offer;

    public Long getId() {
        return id;
    }

    public OfferDetails setId(Long id) {
        this.id = id;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public OfferDetails setDescription(String description) {
        this.description = description;
        return this;
    }

    public boolean isValid() {
        return valid;
    }

    public OfferDetails setValid(boolean valid) {
        this.valid = valid;
        return this;
    }

    public Offer getOffer() {
        return offer;
    }

    public OfferDetails setOffer(Offer offer) {
        this.offer = offer;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        OfferDetails offerDetails = (OfferDetails) o;
        if (offerDetails.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), offerDetails.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "OfferDetails{" +
                "id=" + getId() +
                ", description='" + getDescription() + "'" +
                ", isValid='" + isValid() + "'" +
                "}";
    }
}
