package com.volunteering.app.volunteering.persistence;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "document")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Document implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "document_file", nullable = false)
    private String documentFile;

    @ManyToOne(optional = false)
    @NotNull
    private Offer offer;

    @ManyToOne(optional = false)
    @NotNull
    private User user;

    @ManyToOne(optional = false)
    @NotNull
    private Application application;

    public Long getId() {
        return id;
    }

    public Document setId(Long id) {
        this.id = id;
        return this;
    }

    public String getDocumentFile() {
        return documentFile;
    }

    public Document setDocumentFile(String documentFile) {
        this.documentFile = documentFile;
        return this;
    }

    public Offer getOffer() {
        return offer;
    }

    public Document setOffer(Offer offer) {
        this.offer = offer;
        return this;
    }

    public User getUser() {
        return user;
    }

    public Document setUser(User user) {
        this.user = user;
        return this;
    }

    public Application getApplication() {
        return application;
    }

    public Document setApplication(Application application) {
        this.application = application;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Document document = (Document) o;
        if (document.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), document.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Document{" +
                "id=" + getId() +
                ", documentFile='" + getDocumentFile() + "'" +
                "}";
    }
}
