package com.volunteering.app.volunteering.persistence;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;

/**
 * A Social user.
 */
@Entity
@Table(name = "social_user_connection")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class SocialUserConnection implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "user_id", length = 255, nullable = false)
    private String userId;

    @NotNull
    @Column(name = "provider_id", length = 255, nullable = false)
    private String providerId;

    @NotNull
    @Column(name = "provider_user_id", length = 255, nullable = false)
    private String providerUserId;

    @NotNull
    @Column(nullable = false)
    private Long rank;

    @Column(name = "display_name", length = 255)
    private String displayName;

    @Column(name = "profile_url", length = 255)
    private String profileURL;

    @Column(name = "image_url", length = 255)
    private String imageURL;

    @NotNull
    @Column(name = "access_token", length = 255, nullable = false)
    private String accessToken;

    @Column(length = 255)
    private String secret;

    @Column(name = "refresh_token", length = 255)
    private String refreshToken;

    @Column(name = "expire_time")
    private Long expireTime;

    public Long getId() {
        return id;
    }

    public SocialUserConnection setId(Long id) {
        this.id = id;
        return this;
    }

    public String getUserId() {
        return userId;
    }

    public SocialUserConnection setUserId(String userId) {
        this.userId = userId;
        return this;
    }

    public String getProviderId() {
        return providerId;
    }

    public SocialUserConnection setProviderId(String providerId) {
        this.providerId = providerId;
        return this;
    }

    public String getProviderUserId() {
        return providerUserId;
    }

    public SocialUserConnection setProviderUserId(String providerUserId) {
        this.providerUserId = providerUserId;
        return this;
    }

    public Long getRank() {
        return rank;
    }

    public SocialUserConnection setRank(Long rank) {
        this.rank = rank;
        return this;
    }

    public String getDisplayName() {
        return displayName;
    }

    public SocialUserConnection setDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    public String getProfileURL() {
        return profileURL;
    }

    public SocialUserConnection setProfileURL(String profileURL) {
        this.profileURL = profileURL;
        return this;
    }

    public String getImageURL() {
        return imageURL;
    }

    public SocialUserConnection setImageURL(String imageURL) {
        this.imageURL = imageURL;
        return this;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public SocialUserConnection setAccessToken(String accessToken) {
        this.accessToken = accessToken;
        return this;
    }

    public String getSecret() {
        return secret;
    }

    public SocialUserConnection setSecret(String secret) {
        this.secret = secret;
        return this;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public SocialUserConnection setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
        return this;
    }

    public Long getExpireTime() {
        return expireTime;
    }

    public SocialUserConnection setExpireTime(Long expireTime) {
        this.expireTime = expireTime;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SocialUserConnection user = (SocialUserConnection) o;

        if (!id.equals(user.id)) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "SocialUserConnection{" +
                "id=" + id +
                ", userId=" + userId +
                ", providerId='" + providerId + '\'' +
                ", providerUserId='" + providerUserId + '\'' +
                ", rank=" + rank +
                ", displayName='" + displayName + '\'' +
                ", profileURL='" + profileURL + '\'' +
                ", imageURL='" + imageURL + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", secret='" + secret + '\'' +
                ", refreshToken='" + refreshToken + '\'' +
                ", expireTime=" + expireTime +
                '}';
    }
}
