package com.volunteering.app.volunteering.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

@Entity
@Table(name = "link_type")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class LinkType implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 255)
    @Column(name = "name", length = 255, nullable = false)
    private String name;

    @NotNull
    @Size(max = 255)
    @Column(name = "logo_path", length = 255, nullable = false)
    private String logoPath;

    @OneToMany(mappedBy = "linkType")
    @JsonIgnore
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Link> links = new HashSet<>();

    public Long getId() {
        return id;
    }

    public LinkType setId(Long id) {
        this.id = id;
        return this;
    }

    public String getName() {
        return name;
    }

    public LinkType setName(String name) {
        this.name = name;
        return this;
    }

    public String getLogoPath() {
        return logoPath;
    }

    public LinkType setLogoPath(String logoPath) {
        this.logoPath = logoPath;
        return this;
    }

    public Set<Link> getLinks() {
        return links;
    }

    public LinkType setLinks(Set<Link> links) {
        this.links = links;
        return this;
    }

    public LinkType addLink(Link link) {
        this.links.add(link);
        link.setLinkType(this);
        return this;
    }

    public LinkType removeLink(Link link) {
        this.links.remove(link);
//        link.setLinkType(null);   //LinkType is a Dictionary
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        LinkType linkType = (LinkType) o;
        if (linkType.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), linkType.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "LinkType{" +
                "id=" + getId() +
                ", name='" + getName() + "'" +
                ", logoPath='" + getLogoPath() + "'" +
                "}";
    }
}
