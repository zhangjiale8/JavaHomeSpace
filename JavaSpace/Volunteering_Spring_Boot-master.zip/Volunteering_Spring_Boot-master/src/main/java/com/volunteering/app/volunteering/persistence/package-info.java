package com.volunteering.app.volunteering.persistence;
/**
 * JPA domain objects.
 */
