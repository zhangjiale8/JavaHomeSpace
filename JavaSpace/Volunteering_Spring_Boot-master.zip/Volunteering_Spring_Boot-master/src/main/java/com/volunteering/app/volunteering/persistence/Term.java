package com.volunteering.app.volunteering.persistence;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

@Entity
@Table(name = "term")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Term implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 255)
    @Column(name = "value", length = 255, nullable = false)
    private String value;

    @OneToMany(mappedBy = "term")
    @JsonIgnore
//    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Offer> offers = new HashSet<>();

    public Long getId() {
        return id;
    }

    public Term setId(Long id) {
        this.id = id;
        return this;
    }

    public String getValue() {
        return value;
    }

    public Term setValue(String value) {
        this.value = value;
        return this;
    }

    public Set<Offer> getOffers() {
        return offers;
    }

    public Term setOffers(Set<Offer> offers) {
        this.offers = offers;
        return this;
    }

    public Term addOffer(Offer offer) {
        this.offers.add(offer);
        offer.setTerm(this);
        return this;
    }

    public Term removeOffer(Offer offer) {
        this.offers.remove(offer);
//        offer.setTerm(null);  //Term is a Dictionary
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Term term = (Term) o;
        if (term.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), term.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Term{" +
                "id=" + getId() +
                ", value='" + getValue() + "'" +
                "}";
    }
}
