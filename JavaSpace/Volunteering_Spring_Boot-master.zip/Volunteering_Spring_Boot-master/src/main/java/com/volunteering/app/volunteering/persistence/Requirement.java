package com.volunteering.app.volunteering.persistence;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

@Entity
@Table(name = "requirement")
//@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Requirement implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private Long id;

    @NotNull
    @Size(max = 1)
    @Column(name = "is_obligatory", nullable = false)
    private boolean obligatory;

    @NotNull
    @Size(max = 1000)
    @Column(name = "value", length = 1000, nullable = false)
    private String value;

    @ManyToOne(optional = false)
    @NotNull
    private Offer offer;

    public Long getId() {
        return id;
    }

    public Requirement setId(Long id) {
        this.id = id;
        return this;
    }

    public boolean isObligatory() {
        return obligatory;
    }

    public Requirement setObligatory(boolean obligatory) {
        this.obligatory = obligatory;
        return this;
    }


    public String getValue() {
        return value;
    }

    public Requirement setValue(String value) {
        this.value = value;
        return this;
    }

    public Offer getOffer() {
        return offer;
    }

    public Requirement setOffer(Offer offer) {
        this.offer = offer;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Requirement requirement = (Requirement) o;
        if (requirement.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), requirement.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Requirement{" +
                "id=" + getId() +
                ", isObligatory='" + isObligatory() + "'" +
                ", value='" + getValue() + "'" +
                "}";
    }
}
