# Volunteering 

Application created with Spring Boot and Docker.

## Development

### Building all containers
Build the project (including Docker container images):

	./gradlew buildDocker

Start docker-compose to launch the containers for the application:

	docker-compose -f all.yml up

### Building only database container
Start the database container
    
    docker-compose -f onlydb.yml up  

Then build the project (without a container for the main application):

    ./gradlew build

## Technology
The application was created with the following technologies:
* MySQL 
* Docker / Docker Compose
* Spring Boot
* Hibernate
* Bitronix JTA
* Gradle

## Troubleshooting
May require:
* Re-creating the target database structure
* Re-creating the user ('test' - for the development).

_See 'createDB.sql'._
