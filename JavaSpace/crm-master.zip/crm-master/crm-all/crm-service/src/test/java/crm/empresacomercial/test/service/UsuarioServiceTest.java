package crm.empresacomercial.test.service;

import crm.empresacomercial.test.service.utils.AbstractServiceTest;

public class UsuarioServiceTest extends AbstractServiceTest {

	//	private final Logger LOGGER = Logger.getLogger(this.getClass());



}
