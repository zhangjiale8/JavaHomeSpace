package crm.empresacomercial.utils.services;

import javax.ws.rs.core.MediaType;

public final class ServiceConstants {

	public static final String MEDIA_TYPE = MediaType.APPLICATION_JSON;

}
